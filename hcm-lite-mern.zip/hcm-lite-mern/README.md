# HCM Lite (MERN)

A small Human Capital Management system: employees, attendance, leave, payroll, dashboards, notifications, audit log and an AI assistant.

* **client/** - React 18 + Vite (React Router, Recharts). Plain CSS, responsive down to ~360 px.
* **server/** - Node.js + Express 4 + MongoDB (Mongoose 8), MVC: `models/`, `controllers/`, `routes/` (+ `services/` for business rules, `middleware/`, `validators/`, `utils/`).
* Built from the "Saylani Hackathon - HCM Lite" brief (9 modules, 25 functionalities, business rules, AI features).

> **Verification status - read this first.** The code was written in a sandbox with **no network access**, so `npm install`, a MongoDB server and a Vite build were **not available** there. What *was* verified, and what was *not*, is listed in [Testing and verification status](#testing-and-verification-status). Please run `npm run test` and a manual smoke test (below) on your machine before relying on it.

---

## 1. Quick start

**Prerequisites:** Node.js >= 20, npm >= 9, MongoDB 6/7 (local, Docker or Atlas).

```bash
# 1. install everything (root + server + client)
npm run install:all

# 2. database (pick one)
docker compose up -d            # local MongoDB on 127.0.0.1:27017   (or use your own / Atlas)

# 3. configure the server
cp server/.env.example server/.env
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"   # paste into JWT_SECRET in server/.env

# 4. run API (:5000) and web app (:5173) together
npm run dev
```

Open <http://localhost:5173>. On the **first run** the app shows a *Set up your company* screen: it creates the company, the Admin account and (optionally) the default leave types (Annual 14, Sick 8, Casual 10, Unpaid unlimited). Alternatively set `ADMIN_EMAIL` / `ADMIN_PASSWORD` in `server/.env` and the Admin is created on server start when the database is empty.

Typical first session: *Admin* -> Organization setup (departments, designations, holidays, company hours) -> create an HR login -> sign out -> *HR* (changes the temporary password) -> register employees / managers -> employees sign in, check in, apply for leave -> HR runs payroll -> Admin finalizes.

### Root scripts

| Command | What it does |
|---|---|
| `npm run install:all` | installs root, `server/` and `client/` dependencies |
| `npm run dev` | API (node --watch) + Vite dev server together (`concurrently`) |
| `npm run build` | production build of the client into `client/dist` |
| `npm start` | starts the API; if `client/dist` exists it is served too (single process) |
| `npm test` | server unit + integration tests |
| `npm run test:unit` | dependency-free unit tests only (no MongoDB needed) |
| `npm run test:integration` | supertest + in-memory MongoDB suites |

### Production notes

```bash
npm run build                 # client/dist
NODE_ENV=production npm start # API serves the API, /uploads and the built client
```
In production `JWT_SECRET` must be >= 32 random characters, `EXPOSE_TEMP_PASSWORD` must be `false` and `MAIL_MODE=smtp` with real SMTP settings (the server refuses to start otherwise). Put it behind HTTPS and set `TRUST_PROXY=1` when behind a reverse proxy so rate limits see real client IPs. If the client is hosted separately, set `VITE_API_URL` at build time and `CLIENT_ORIGIN` on the server.

---

## 2. Environment variables

### `server/.env` (see `server/.env.example`)

| Variable | Default | Notes |
|---|---|---|
| `NODE_ENV` | `development` | `production` enables the strict config checks |
| `PORT` | `5000` | |
| `MONGODB_URI` | `mongodb://127.0.0.1:27017/hcm_lite` | local, Docker or Atlas URI |
| `JWT_SECRET` | - **required** | random, >= 32 chars in production |
| `JWT_EXPIRES_IN` | `8h` | token expiry |
| `BCRYPT_ROUNDS` | `12` | |
| `RESET_TOKEN_TTL_MINUTES` | `30` | password-reset link lifetime |
| `CLIENT_ORIGIN` | `http://localhost:5173` | CORS allow-list (comma separated) |
| `APP_URL` | `http://localhost:5173` | used to build the reset link in emails |
| `ADMIN_NAME/EMAIL/PASSWORD`, `COMPANY_NAME` | empty | optional first-run bootstrap |
| `MAIL_MODE` | `outbox` (dev) / `smtp` (prod) | `smtp`, `outbox` (dev only: JSON files in `server/.outbox/`), `off` |
| `MAIL_FROM`, `SMTP_HOST/PORT/SECURE/USER/PASS` | - | required for `smtp` |
| `EXPOSE_TEMP_PASSWORD` | `false` (`true` in the example file) | dev convenience: return the temporary password once to the HR/Admin who registers someone. **Set `false` in production.** |
| `UPLOAD_DIR` | `uploads` | profile photos live in `<UPLOAD_DIR>/profiles` |
| `RATE_LIMIT_DISABLED` | `false` | only for tests |
| `AI_API_KEY`, `AI_BASE_URL`, `AI_MODEL`, `AI_TIMEOUT_MS`, `AI_REQUESTS_PER_HOUR` | empty / OpenAI / `gpt-4o-mini` / 15000 / 20 | any OpenAI-compatible chat-completions API with tool calling. Without a key the AI features degrade gracefully. |
| `TRUST_PROXY` | unset | set to `1` behind one reverse proxy |

### `client/.env` (see `client/.env.example`)

`VITE_API_URL` (empty in dev - Vite proxies `/api` and `/uploads`), `VITE_PROXY_TARGET` (dev proxy target, default `http://localhost:5000`).

### Email in development
With `MAIL_MODE=outbox` nothing is sent; each email (welcome, reset link, leave decision, payslip ready...) is written to `server/.outbox/*.json`. Open the newest file to copy a password-reset link. Reset tokens and passwords are **never written to the application log**, and the outbox is development-only (refused in production).

---

## 3. Roles and permissions

Roles: **admin**, **hr**, **manager**, **employee**. The brief defines Admin/HR/Employee; the *manager* role was added for team-scoped approvals ("manager team boundaries"). A manager is an employee who has direct reports (`managerId`).

| Capability | Admin | HR | Manager | Employee |
|---|---|---|---|---|
| Company settings, departments, designations, leave types, holidays | manage | read | read | read |
| Create / deactivate / reset logins | HR + anyone | - | - | - |
| Register / edit employees, CSV import/export, exit | view | **manage** | team: view | self: view/edit phone+address+photo |
| See salary structure | view | view + edit | **no** | **no** |
| Check in/out, request corrections | - (no employee record) | own | own | own |
| Attendance board | all | all | **own team only** | - |
| Apply for leave | - | own | own | own |
| Approve/reject leave & corrections | HR staff requests only | anyone except self | **direct reports only** | - |
| Run payroll draft | - | **yes** | - | - |
| Finalize (lock) payroll | **yes** | - | - | - |
| Payslips | any | any | own (finalized) | own (finalized) |
| Audit log | **yes** | - | - | - |
| Dashboards | company | HR | team + self | self |

Rules enforced in `server/src/config/permissions.js` (feature access) and `server/src/utils/scope.js` + `services/approval.js` (data scope). Nobody can approve their own request; Admin may decide only requests raised by HR staff (otherwise an HR user's request would have no approver).

---

## 4. Business rules

**Attendance.** The server stamps all times. One record per employee per day (unique index) - a second check-in returns **409**, including under concurrent requests. Late = check-in after `office start + grace` (default 09:00 + 15 min; 09:15:00 is on time). Duration = whole minutes between check-in and check-out. Worked < half-day threshold (default 5 h) -> `half_day`. Checked in but never out, once the day is over -> `missing_checkout`. Working day with no record and no approved leave -> `absent`. Rules are **snapshotted on each record**, so later settings changes only affect new records. Corrections (last 30 days) go to a manager/HR approval and create/replace the record when approved.

**Leave.** Counts **working days only** (weekends and public holidays excluded). 422 for: end before start, a range with no working days, overlap with a pending/approved request, balance exceeded (pending requests reserve balance), start before joining date, > 30 days in the past, > 1 year ahead, or a request spanning two calendar years. Reject requires a comment. Decisions are atomic (a second decision returns 409). Employees can cancel pending requests and future approved ones.

**Payroll** (`server/src/utils/payroll.js`, unit-tested):

```
gross        = basic + HRA (40% of basic) + medical (10% of basic)        (= 1.5 x basic)
W            = working days in the month (weekends and public holidays excluded)
E            = working days between join date and exit date inside the month
perDay       = gross / W
deductDays   = absent days + unpaid-leave days + 0.5 x half days          (days strictly before today)
earnedGross  = perDay x E                    -> prorates joiners and leavers
deduction    = perDay x deductDays
payableGross = earnedGross - deduction
tax          = slab(gross x 12) / 12 x (E / W), never more than payableGross
net          = payableGross - tax
```
* **Paid leave** (annual/sick/casual), **weekends** and **public holidays** never reduce pay. **Unpaid leave** and **absences** deduct 1 day each; a **half day** deducts 0.5. If an attendance record exists for a day it wins over a leave record.
* In the current month, today and future days are assumed worked (recalculate the draft later in the month).
* Annual tax slabs (illustrative, from the brief): 0-600k: 0; 600k-1.2M: 5% over 600k; 1.2M-2.4M: 30k + 15%; 2.4M-3.6M: 210k + 25%; above: 510k + 35% over 3.6M.
* *Worked example* - basic 100,000, October 2026 (22 working days), 2 absences + 1 half day: gross 150,000; per-day 6,818.18; deducted days 2.5; deduction 17,045.45; payable 132,954.55; tax 120,000/12 = 10,000; **net 122,954.55**.
* HR creates/recalculates a **draft**; Admin **finalizes**, which locks the month (further runs return 409) and makes payslips visible to employees (with notification + email). Payslips snapshot all figures, so later salary edits never change them. PDF payslips are generated server-side.

**Dashboards** (server-computed; scope = the caller's own data): attendance rate = (present + late + missing_checkout + 0.5 x half_day) / (working-day records - on_leave); late % = late / (present + late); absenteeism = absent / expected working days; attrition = exits / average headcount; headcount counts active + probation on the end date. Attendance absences are derived in service code from lean record projections (an absence is the *lack* of a record, so it cannot be a pure `$group`); payroll, leave, headcount and cost figures use MongoDB aggregation.

---

## 5. API overview (all under `/api`, JSON; `{ data, pagination? }` or `{ error: { message, code, details? } }`)

| Area | Endpoints |
|---|---|
| Setup/Auth | `GET /setup/status`, `POST /setup`, `POST /auth/login`, `GET /auth/me`, `POST /auth/change-password`, `POST /auth/forgot-password`, `POST /auth/reset-password`, `POST /auth/logout` |
| Settings/org | `GET/PUT /settings`; CRUD `/departments`, `/designations`, `/leave-types`, `/holidays` |
| Logins | `GET /users`, `POST /users/hr`, `PATCH /users/:id/active`, `POST /users/:id/reset-password` |
| Employees | `GET/POST /employees`, `GET/PATCH /employees/:id`, `PUT /employees/:id/salary`, `POST /employees/:id/exit`, `POST /employees/:id/photo`, `PATCH /employees/me`, `POST /employees/me/photo`, `POST /employees/import[?dryRun=true]`, `GET /employees/export` |
| Attendance | `POST /attendance/check-in`, `/check-out`, `GET /attendance/today`, `/me?month=`, `/board`, `/employee/:id?month=`, corrections: `GET/POST /attendance/corrections`, `POST /attendance/corrections/:id/decision` |
| Leave | `GET /leaves/balance`, `POST /leaves/preview`, `GET/POST /leaves`, `POST /leaves/:id/cancel`, `POST /leaves/:id/decision` |
| Payroll | `GET/POST /payroll/runs`, `GET /payroll/runs/:id`, `POST /payroll/runs/:id/finalize`, `GET /payroll/payslips`, `/payslips/:id`, `/payslips/:id/pdf` |
| Dashboards | `GET /dashboard/admin`, `/dashboard/hr`, `/dashboard/me` |
| Comms/audit | `GET/POST/DELETE /announcements`, `GET /notifications`, `POST /notifications/read-all`, `POST /notifications/:id/read`, `GET /audit` |
| AI | `POST /ai/chat`, `POST /ai/summary`, `POST /ai/smart-leave` |

Lists are paginated (`page`, `limit`, max 100) and filterable. Deleting an employee is an **exit** (record kept for payroll history and audit integrity; login disabled).

### AI features
Provider-agnostic, server-side only (the key never reaches the browser), 15 s timeout, ~20 requests/user/hour, every call logged in `AiLog`. **Chat** uses tool calls (headcount, attendance summary, late-comers, leave summary, own leave balance, payroll summary, employee search) that call the *same services as the REST API with the caller's permissions*; policy answers come from rules generated from live settings. **Dashboard summary** recomputes the KPI JSON on the server and asks for 3-5 bullets (a deterministic fallback is shown if AI fails). **Smart leave** turns a sentence into a pre-filled form (validated, one retry) and never submits anything. Not exercised against a live model here.

---

## 6. Security summary

* bcrypt password hashes (`bcryptjs`, pure JS implementation of bcrypt); passwords 8-72 chars with letter + number.
* JWT (HS256) with expiry; a per-user `tokenVersion` is checked on every request, so password change/reset and deactivation invalidate existing tokens immediately. Temporary passwords force a change before any other API call.
* Password reset: 256-bit random token, only its SHA-256 hash stored, 30-minute expiry, **single use** (consumed atomically), newer request replaces older, identical response for unknown emails, never logged.
* Role permissions + data scope on the server for every route (UI hiding is cosmetic); manager team boundary; payroll/salary restricted to HR/Admin; employees see only finalized own payslips.
* Zod validation on every body/query/param (unknown fields stripped -> no mass assignment); request sanitiser removes `$`/dotted keys and HTML tags; regex search inputs are escaped.
* Uploads: type checked by magic bytes (JPEG/PNG/WebP), 2 MB limit, server-generated random filenames (client filename never used), served with `nosniff`. CSV: `.csv` only, 1 MB, 500 rows, exports neutralise spreadsheet-formula injection.
* Helmet, CORS allow-list, global + per-endpoint rate limits (login 10/15 min, reset 5/h, AI per user), 100 kb JSON limit, centralized error handler (no stack traces/internal details to clients), logs redact tokens/passwords/pay data.
* Append-only audit log (model-level update/delete blocked; no API for it); passwords/tokens redacted.
* Known trade-offs: the JWT is kept in `localStorage` (XSS-exposed; mitigated by React escaping, Helmet and no HTML rendering of user data - move to httpOnly cookies + CSRF protection if you need to harden further); profile photos are served statically under unguessable names rather than behind auth; MongoDB transactions are not used (standalone-friendly), so multi-document flows use atomic single-document updates and manual compensation.

---

## 7. Testing and verification status

| Check | Result |
|---|---|
| **Unit tests** (`server/tests/unit`, Node's built-in runner, no dependencies): payroll formula (full month, absences, unpaid/paid leave, holidays, half days, joiner/leaver proration, tax slabs, clamping), attendance rules (late boundary, duration, half-day, missing check-out, snapshotted rules), working-day/leave-day counting, dashboard metric formulas, CSV parser/writer, date/timezone helpers, RBAC matrix and data-scope rules | **35 / 35 passed** (executed) |
| Syntax check of every server file (`node --check`) | passed |
| Module-graph load of the whole server against stubbed third-party packages: every internal `require`, every destructured import, every route -> controller -> service reference resolves (260 member references) | passed |
| Client: every source file transpiled and the **entire app bundled with esbuild** (all pages/components resolve their imports and named exports) | passed |
| **Integration tests** (`server/tests/integration`, supertest + mongodb-memory-server): auth (setup-once, login, JWT expiry/forgery, forced password change, reset token single-use/expiry, sanitisation), RBAC (employee/manager/HR/admin boundaries, team scope, mass-assignment, upload validation), attendance (duplicate and concurrent check-in, duration, half-day, snapshotted rules, corrections), leave (day counting, overlap, balance, holidays, approval flow, self-approval, cancel), payroll (draft/finalize/lock, payslip visibility, PDF, audit immutability, CSV import) | **written but NOT executed** (needs `npm install` + a MongoDB binary download) |
| `npm install`, `vite build`, running the API against MongoDB, live SMTP, live AI provider, PDF rendering, browser/responsive testing | **not run** in the sandbox |

Expect to find small integration issues the first time you run it (typos in unexecuted paths, version-specific library behaviour). The pure business logic is the part that is proven; the glue is carefully cross-checked but not run.

To run the tests locally: `npm run test:unit` (instant) and `npm run test:integration` (first run downloads a MongoDB binary; set `MONGOMS_SYSTEM_BINARY=/path/to/mongod` to reuse an installed one).

**Suggested 10-minute smoke test:** set up the company -> create a department -> create an HR login -> sign in as HR (change password) -> register a manager and two employees -> sign in as an employee: check in / out, apply for leave -> as the manager approve it -> as HR run payroll for the current month -> as Admin finalize -> as the employee open the payslip PDF.

---

## 8. Not implemented / limitations

* **Camera / face attendance and geofence enforcement** (the brief's optional bonus): not built. Office latitude/longitude/radius are stored in settings only.
* Leave requests cannot span two calendar years (documented rule; submit two requests). Half-day leave is not supported. Managers see direct reports only (not indirect).
* CSV import resolves `manager_code` only against managers that already exist in the database.
* No refresh tokens / "remember me"; sessions last `JWT_EXPIRES_IN`.
* Tax slabs are the brief's illustrative slabs, not a statutory calculation.
* The board and dashboards load a company's employees into memory per request - fine for hundreds of employees, not tuned for tens of thousands.

## 9. Project layout

```
hcm-lite-mern/
  package.json            root scripts (dev / build / start / test)
  docker-compose.yml      optional local MongoDB
  client/                 React + Vite app (src/pages, src/components, src/context, src/api.js)
  server/
    .env.example
    src/
      app.js server.js
      config/             env, db, permissions (RBAC matrix)
      models/             17 Mongoose models + indexes
      controllers/        thin HTTP layer
      routes/index.js     routes + permission/validation guards
      services/           business rules (attendance, leave, payroll, dashboards, AI, mail...)
      middleware/         auth, validate, sanitize, rateLimit, upload, errorHandler
      validators/         zod schemas
      utils/              pure logic: payroll, dates, working days, attendance rules, metrics, csv, scope
    tests/unit, tests/integration
```
