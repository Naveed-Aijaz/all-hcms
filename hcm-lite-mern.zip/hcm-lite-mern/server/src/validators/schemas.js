'use strict';
const { z } = require('zod');
const { isValidISODate, isValidMonth, isValidTimezone } = require('../utils/dates');

const objectId = z.string().regex(/^[a-f0-9]{24}$/i, 'Invalid id');
const isoDate = z.string().refine(isValidISODate, 'Must be a valid date (YYYY-MM-DD)');
const month = z.string().refine(isValidMonth, 'Must be a month (YYYY-MM)');
const hhmm = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Must be HH:mm');
const email = z.string().trim().toLowerCase().email('Invalid email').max(254);
const shortText = (max = 120) => z.string().trim().min(1, 'Required').max(max);
const optText = (max = 300) => z.string().trim().max(max).optional().or(z.literal(''));
const phone = z.string().trim().regex(/^[0-9+()\-\s]{0,30}$/, 'Invalid phone number').max(30);
const password = z
  .string()
  .min(8, 'At least 8 characters')
  .max(72, 'At most 72 characters')
  .refine((p) => /[A-Za-z]/.test(p) && /\d/.test(p), 'Must contain a letter and a number');
const page = { page: z.coerce.number().int().min(1).optional(), limit: z.coerce.number().int().min(1).max(100).optional() };
const idParam = z.object({ id: objectId });
const boolish = z.enum(['true', 'false']).optional();

const s = {};

// ---- auth / setup
s.setup = z.object({
  companyName: shortText(120),
  adminName: shortText(120),
  adminEmail: email,
  adminPassword: password,
  seedDefaults: z.boolean().optional(),
});
s.login = z.object({ email, password: z.string().min(1).max(200) });
s.changePassword = z.object({ currentPassword: z.string().min(1).max(200), newPassword: password });
s.forgot = z.object({ email });
s.reset = z.object({ token: z.string().regex(/^[a-f0-9]{64}$/, 'Invalid token'), newPassword: password });

// ---- settings & org
s.settings = z.object({
  companyName: shortText(120).optional(),
  timezone: z.string().refine(isValidTimezone, 'Unknown timezone').optional(),
  officeStart: hhmm.optional(),
  graceMinutes: z.number().int().min(0).max(180).optional(),
  halfDayHours: z.number().min(1).max(12).optional(),
  weekend: z.array(z.number().int().min(0).max(6)).max(6).optional(),
  office: z
    .object({
      lat: z.number().min(-90).max(90).nullable().optional(),
      lng: z.number().min(-180).max(180).nullable().optional(),
      radiusMeters: z.number().min(10).max(5000).optional(),
    })
    .optional(),
  payroll: z
    .object({ hraPercent: z.number().min(0).max(100).optional(), medicalPercent: z.number().min(0).max(100).optional() })
    .optional(),
});
s.department = z.object({ name: shortText(80), description: optText(300) });
s.designation = z.object({ title: shortText(80), departmentId: objectId.nullable().optional() });
s.leaveType = z.object({
  name: shortText(60),
  code: z.string().trim().min(1).max(20).regex(/^[A-Za-z0-9_-]+$/, 'Letters, numbers, - and _ only'),
  annualQuota: z.number().min(0).max(366).optional(),
  unlimited: z.boolean().optional(),
  paid: z.boolean().optional(),
});
s.holiday = z.object({ date: isoDate, name: shortText(100) });

// ---- users & employees
const employeeBase = {
  code: z.string().trim().min(1).max(30).regex(/^[A-Za-z0-9_-]+$/, 'Letters, numbers, - and _ only').optional(),
  name: shortText(120),
  email,
  phone: phone.optional(),
  address: optText(300),
  gender: z.enum(['male', 'female', 'other']).optional(),
  dob: isoDate.nullable().optional(),
  departmentId: objectId,
  designationId: objectId.nullable().optional(),
  managerId: objectId.nullable().optional(),
  joinDate: isoDate,
  status: z.enum(['probation', 'active']).optional(),
  basicSalary: z.number().positive('Salary must be greater than 0').max(100000000),
};
s.employeeCreate = z.object({ ...employeeBase, role: z.enum(['employee', 'manager']).optional() });
s.hrCreate = z.object(employeeBase);
s.employeeUpdate = z
  .object({
    name: shortText(120),
    email,
    phone,
    address: z.string().trim().max(300),
    gender: z.enum(['male', 'female', 'other']),
    dob: isoDate.nullable(),
    departmentId: objectId,
    designationId: objectId.nullable(),
    managerId: objectId.nullable(),
    joinDate: isoDate,
    status: z.enum(['probation', 'active']),
    role: z.enum(['employee', 'manager']),
  })
  .partial();
s.selfUpdate = z.object({ phone: phone.optional(), address: z.string().trim().max(300).optional() });
s.salaryUpdate = z.object({ basicSalary: z.number().positive('Salary must be greater than 0').max(100000000) });
s.exitEmployee = z.object({ exitDate: isoDate });
s.employeeList = z.object({
  ...page,
  search: z.string().trim().max(80).optional(),
  departmentId: objectId.optional(),
  status: z.enum(['probation', 'active', 'exited']).optional(),
  role: z.enum(['hr', 'manager', 'employee']).optional(),
  sort: z.enum(['name', '-name', 'joinDate', '-joinDate', 'code']).optional(),
});
s.userList = z.object({ ...page, search: z.string().trim().max(80).optional(), role: z.enum(['admin', 'hr', 'manager', 'employee']).optional() });
s.userActive = z.object({ active: z.boolean() });
s.importQuery = z.object({ dryRun: boolish });

// ---- attendance
s.monthQuery = z.object({ month: month.optional() });
s.boardQuery = z.object({ date: isoDate.optional(), departmentId: objectId.optional(), ...page });
s.correctionCreate = z.object({ date: isoDate, checkIn: hhmm, checkOut: hhmm.nullable().optional(), reason: shortText(500) });
s.correctionList = z.object({ ...page, status: z.enum(['pending', 'approved', 'rejected']).optional(), scope: z.enum(['mine', 'team']).optional() });
s.decision = z.object({ decision: z.enum(['approve', 'reject']), comment: z.string().trim().max(500).optional() });

// ---- leave
s.leaveApply = z.object({ leaveTypeId: objectId, startDate: isoDate, endDate: isoDate, reason: z.string().trim().max(500).optional() });
s.leavePreview = z.object({ leaveTypeId: objectId, startDate: isoDate, endDate: isoDate });
s.leaveList = z.object({ ...page, status: z.enum(['pending', 'approved', 'rejected', 'cancelled']).optional(), employeeId: objectId.optional(), scope: z.enum(['mine', 'team']).optional() });
s.balanceQuery = z.object({ employeeId: objectId.optional(), year: z.coerce.number().int().min(2000).max(2100).optional() });

// ---- payroll
s.payrollRun = z.object({ month });
s.payslipList = z.object({ ...page, employeeId: objectId.optional(), month: month.optional() });

// ---- dashboards & comms
s.dashboardQuery = z.object({ from: isoDate.optional(), to: isoDate.optional(), departmentId: objectId.optional() });
s.announcement = z.object({ title: shortText(140), body: shortText(2000) });
s.notificationList = z.object({ ...page, unread: boolish });
s.auditList = z.object({ ...page, entity: z.string().trim().max(40).optional(), action: z.string().trim().max(60).optional(), actorId: objectId.optional() });

// ---- AI
s.aiChat = z.object({ message: z.string().trim().min(1).max(1000) });
s.aiSummary = z.object({ dashboard: z.enum(['admin', 'hr']), from: isoDate.optional(), to: isoDate.optional(), departmentId: objectId.optional() });
s.aiSmartLeave = z.object({ text: z.string().trim().min(3).max(500) });

module.exports = { s, idParam, objectId, isoDate, month };
