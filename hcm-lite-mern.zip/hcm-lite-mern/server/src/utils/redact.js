'use strict';
const ALWAYS = /(pass(word)?|hash|token|secret|authorization|cookie|api[-_]?key)/i;
const FINANCIAL = /(salary|basic|gross|net|tax|allowance|payslip)/i;

/** Deep-clone with sensitive values replaced. `financial:true` also hides pay data (used for logs). */
function redact(value, { financial = false, depth = 0 } = {}) {
  if (value === null || value === undefined || depth > 6) return value;
  if (Array.isArray(value)) return value.map((v) => redact(v, { financial, depth: depth + 1 }));
  if (value instanceof Date) return value;
  if (typeof value === 'object') {
    if (typeof value.toObject === 'function') return redact(value.toObject(), { financial, depth });
    if (value._bsontype === 'ObjectId' || value._bsontype === 'ObjectID') return String(value);
    const out = {};
    for (const [k, v] of Object.entries(value)) {
      if (ALWAYS.test(k) || (financial && FINANCIAL.test(k))) out[k] = '[REDACTED]';
      else out[k] = redact(v, { financial, depth: depth + 1 });
    }
    return out;
  }
  return value;
}

module.exports = { redact };
