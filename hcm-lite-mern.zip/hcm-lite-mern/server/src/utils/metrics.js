'use strict';
/** Dashboard metric formulas (brief section 7). Pure functions, unit tested. */
const pct = (num, den) => (den > 0 ? Math.round((num / den) * 10000) / 100 : null);

/** (present + late + missing_checkout + 0.5 x half_day) / (working-day records - on_leave) */
function attendanceRate(c) {
  const present = c.present || 0;
  const late = c.late || 0;
  const missing = c.missing_checkout || 0;
  const half = c.half_day || 0;
  const absent = c.absent || 0;
  const denominator = present + late + missing + half + absent; // excludes on_leave
  return pct(present + late + missing + 0.5 * half, denominator);
}

/** late / (present + late) */
function latePercent(c) {
  return pct(c.late || 0, (c.present || 0) + (c.late || 0));
}

/** absent days / expected working days */
function absenteeism(absentDays, expectedWorkingDays) {
  return pct(absentDays, expectedWorkingDays);
}

/** exits in period / average headcount x 100 */
function attrition(exits, headcountStart, headcountEnd) {
  return pct(exits, (headcountStart + headcountEnd) / 2);
}

/** approved days / quota */
function leaveUtilization(approvedDays, quota) {
  return pct(approvedDays, quota);
}

module.exports = { pct, attendanceRate, latePercent, absenteeism, attrition, leaveUtilization };
