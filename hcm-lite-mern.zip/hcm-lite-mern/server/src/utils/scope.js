'use strict';
/**
 * Data-scope rules. Returned filters are plain Mongo filter objects so the
 * same rule is applied by REST controllers, dashboards and AI tools.
 *
 *  admin, hr -> every employee
 *  manager   -> self + direct reports (managerId === manager's employeeId)
 *  employee  -> self only
 */
const idStr = (v) => (v === null || v === undefined ? '' : String(v._id || v));

function employeeFilter(user) {
  if (user.role === 'admin' || user.role === 'hr') return {};
  if (!user.employeeId) return { _id: null }; // matches nothing
  if (user.role === 'manager') return { $or: [{ _id: user.employeeId }, { managerId: user.employeeId }] };
  return { _id: user.employeeId };
}

function isEmployeeInScope(user, employee) {
  if (!employee) return false;
  if (user.role === 'admin' || user.role === 'hr') return true;
  if (!user.employeeId) return false;
  if (idStr(employee) === idStr(user.employeeId)) return true;
  return user.role === 'manager' && idStr(employee.managerId) === idStr(user.employeeId);
}

/** Approval inbox filter: managers only see direct reports, never themselves. */
function approvalFilter(user) {
  if (user.role === 'admin' || user.role === 'hr') return {};
  if (user.role === 'manager' && user.employeeId) return { managerId: user.employeeId };
  return { _id: null };
}

module.exports = { employeeFilter, isEmployeeInScope, approvalFilter, idStr };
