'use strict';
const crypto = require('crypto');

/** Opaque random token (sent to the user) and its SHA-256 hash (stored). */
function newOpaqueToken() {
  const token = crypto.randomBytes(32).toString('hex');
  return { token, hash: hashToken(token) };
}
const hashToken = (t) => crypto.createHash('sha256').update(String(t)).digest('hex');

/** Cryptographically random temporary password that satisfies the password policy. */
function temporaryPassword() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
  const bytes = crypto.randomBytes(12);
  let out = '';
  for (let i = 0; i < 12; i += 1) out += alphabet[bytes[i] % alphabet.length];
  return `${out}#7a`; // guarantees a digit + symbol + letters
}

module.exports = { newOpaqueToken, hashToken, temporaryPassword };
