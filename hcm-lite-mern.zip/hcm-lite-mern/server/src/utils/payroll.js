'use strict';
/**
 * PAYROLL FORMULA (documented in README):
 *
 *  gross        = basic + HRA (40% of basic) + medical (10% of basic) = 1.5 x basic
 *  W            = working days in the month (weekends and public holidays excluded)
 *  E            = working days inside the employment period (join date .. exit date)
 *  perDay       = gross / W
 *  evaluated    = eligible working days strictly before today
 *                 (today and future days of the current month are assumed worked)
 *  deductDays   = absent + unpaid leave + 0.5 x half days   (evaluated days only)
 *  earnedGross  = perDay x E                  (prorates joiners / leavers)
 *  deduction    = perDay x deductDays
 *  payableGross = earnedGross - deduction
 *  tax          = slab(gross x 12) / 12 x (E / W), never more than payableGross
 *  net          = payableGross - tax
 *
 * Paid leave (annual/sick/casual), weekends and public holidays never reduce pay.
 * If an attendance record exists for a day it wins over a leave record.
 */
const { listWorkingDays } = require('./workingDays');

const TAX_SLABS = [
  { upTo: 600000, base: 0, rate: 0, from: 0 },
  { upTo: 1200000, base: 0, rate: 0.05, from: 600000 },
  { upTo: 2400000, base: 30000, rate: 0.15, from: 1200000 },
  { upTo: 3600000, base: 210000, rate: 0.25, from: 2400000 },
  { upTo: Infinity, base: 510000, rate: 0.35, from: 3600000 },
];

const round2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;

function annualTax(annualGross, slabs = TAX_SLABS) {
  if (!(annualGross > 0)) return 0;
  const slab = slabs.find((s) => annualGross <= s.upTo) || slabs[slabs.length - 1];
  return slab.base + (annualGross - slab.from) * slab.rate;
}

function salaryStructure(basic, { hraPercent = 40, medicalPercent = 10 } = {}) {
  const b = round2(Number(basic) || 0);
  const hra = round2((b * hraPercent) / 100);
  const medical = round2((b * medicalPercent) / 100);
  return { basic: b, hra, medical, gross: round2(b + hra + medical) };
}

/**
 * i = { basic, rules:{hraPercent, medicalPercent}, monthStart, monthEnd,
 *       joinDate, exitDate|null, weekend:number[], holidays:string[],
 *       attendance:{date:status}, leaves:{date:{paid:boolean}}, today }
 */
function computePayslip(i) {
  const sal = salaryStructure(i.basic, i.rules);
  const monthDays = listWorkingDays(i.monthStart, i.monthEnd, { weekend: i.weekend, holidays: i.holidays });
  const W = monthDays.length;
  const eligible = monthDays.filter((d) => d >= i.joinDate && (!i.exitDate || d <= i.exitDate));
  const E = eligible.length;
  const attendance = i.attendance || {};
  const leaves = i.leaves || {};

  let present = 0;
  let halfDays = 0;
  let absent = 0;
  let paidLeave = 0;
  let unpaidLeave = 0;
  for (const d of eligible) {
    if (d >= i.today) continue; // not evaluated yet
    const att = attendance[d];
    if (att) {
      if (att === 'half_day') halfDays += 1;
      else present += 1; // present | late | missing_checkout
      continue;
    }
    const lv = leaves[d];
    if (lv) {
      if (lv.paid) paidLeave += 1;
      else unpaidLeave += 1;
      continue;
    }
    absent += 1;
  }

  const deductDays = absent + unpaidLeave + 0.5 * halfDays;
  const perDay = W > 0 ? sal.gross / W : 0;
  const earnedGross = round2(perDay * E);
  const deduction = round2(perDay * deductDays);
  const payableGross = round2(earnedGross - deduction);
  const proration = W > 0 ? E / W : 0;
  const tax = round2(Math.min((annualTax(sal.gross * 12) / 12) * proration, Math.max(payableGross, 0)));
  const net = round2(payableGross - tax);

  return {
    ...sal,
    workingDays: W,
    eligibleDays: E,
    presentDays: present,
    halfDays,
    absentDays: absent,
    paidLeaveDays: paidLeave,
    unpaidLeaveDays: unpaidLeave,
    deductDays,
    perDay: round2(perDay),
    earnedGross,
    deduction,
    payableGross,
    tax,
    net,
  };
}

module.exports = { TAX_SLABS, annualTax, salaryStructure, computePayslip, round2 };
