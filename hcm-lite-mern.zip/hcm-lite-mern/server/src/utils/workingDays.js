'use strict';
const { eachDay, weekdayOf } = require('./dates');

/**
 * Working days = every calendar day that is not a weekend day and not a
 * public holiday. `weekend` is an array of weekday numbers (0=Sun..6=Sat).
 * `holidays` is an iterable of ISO date strings.
 */
function listWorkingDays(start, end, { weekend = [0, 6], holidays = [] } = {}) {
  const hol = holidays instanceof Set ? holidays : new Set(holidays);
  const wk = new Set(weekend);
  return eachDay(start, end).filter((d) => !wk.has(weekdayOf(d)) && !hol.has(d));
}

function countWorkingDays(start, end, opts) {
  return listWorkingDays(start, end, opts).length;
}

module.exports = { listWorkingDays, countWorkingDays };
