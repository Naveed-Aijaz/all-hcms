'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { listWorkingDays, countWorkingDays } = require('../../src/utils/workingDays');
const { isLateCheckIn, workedMinutes, computeStatus } = require('../../src/utils/attendanceRules');
const { isValidISODate, isValidMonth, addDays, monthRange, dateInTz, zonedTimeToUtc, startOfWeek } = require('../../src/utils/dates');
const m = require('../../src/utils/metrics');
const { parseCsv, toCsv } = require('../../src/utils/csv');

const rules = { startTime: '09:00', graceMinutes: 15, halfDayHours: 5, timezone: 'Asia/Karachi' };
const at = (hhmm, date = '2026-10-26') => zonedTimeToUtc(date, hhmm, 'Asia/Karachi');

test('date validation rejects impossible dates', () => {
  assert.equal(isValidISODate('2026-02-29'), false);
  assert.equal(isValidISODate('2028-02-29'), true);
  assert.equal(isValidISODate('2026-13-01'), false);
  assert.equal(isValidISODate('26-01-01'), false);
  assert.equal(isValidMonth('2026-10'), true);
  assert.equal(isValidMonth('2026-00'), false);
});

test('date arithmetic and month ranges', () => {
  assert.equal(addDays('2026-10-31', 1), '2026-11-01');
  assert.equal(addDays('2026-03-01', -1), '2026-02-28');
  assert.deepEqual(monthRange('2026-02'), { start: '2026-02-01', end: '2026-02-28', days: 28 });
  assert.equal(startOfWeek('2026-10-24'), '2026-10-19'); // Saturday -> Monday
  assert.equal(startOfWeek('2026-10-25'), '2026-10-19'); // Sunday  -> Monday
});

test('timezone conversion round-trips', () => {
  const d = at('09:15');
  assert.equal(dateInTz(d, 'Asia/Karachi'), '2026-10-26');
  assert.equal(d.toISOString(), '2026-10-26T04:15:00.000Z'); // PKT = UTC+5
});

test('working days skip weekends and holidays', () => {
  assert.equal(countWorkingDays('2026-10-19', '2026-10-25'), 5); // Mon-Sun
  assert.equal(countWorkingDays('2026-10-19', '2026-10-25', { holidays: ['2026-10-21'] }), 4);
  assert.deepEqual(listWorkingDays('2026-10-24', '2026-10-25'), []); // Sat+Sun
  assert.equal(countWorkingDays('2026-10-19', '2026-10-25', { weekend: [5, 6] }), 5); // Fri/Sat weekend
  assert.equal(countWorkingDays('2026-10-26', '2026-10-25'), 0); // inverted range
});

test('late rule: on time until 09:15:00, late after', () => {
  assert.equal(isLateCheckIn(at('09:00'), rules), false);
  assert.equal(isLateCheckIn(at('09:15'), rules), false);
  assert.equal(isLateCheckIn(new Date(at('09:15').getTime() + 1000), rules), true);
  assert.equal(isLateCheckIn(at('10:30'), rules), true);
});

test('late rule uses the snapshotted rules, not current settings', () => {
  const relaxed = { ...rules, startTime: '10:00' };
  assert.equal(isLateCheckIn(at('09:40'), relaxed), false);
  assert.equal(isLateCheckIn(at('09:40'), rules), true);
});

test('worked duration is calculated in whole minutes and never negative', () => {
  assert.equal(workedMinutes(at('09:00'), at('17:30')), 510);
  assert.equal(workedMinutes(at('09:00'), new Date(at('09:00').getTime() + 59999)), 0);
  assert.equal(workedMinutes(at('17:00'), at('09:00')), 0);
  assert.equal(workedMinutes(at('09:00'), null), 0);
});

test('status: half_day under 5h, late/present, missing_checkout after the day', () => {
  const rec = (o) => ({ date: '2026-10-26', late: false, ...o });
  assert.equal(computeStatus(rec({ checkIn: at('09:00'), checkOut: at('13:59') }), rules, '2026-10-27'), 'half_day');
  assert.equal(computeStatus(rec({ checkIn: at('09:00'), checkOut: at('14:00') }), rules, '2026-10-27'), 'present');
  assert.equal(computeStatus(rec({ checkIn: at('09:30'), late: true, checkOut: at('18:00') }), rules, '2026-10-27'), 'late');
  assert.equal(computeStatus(rec({ checkIn: at('09:00') }), rules, '2026-10-27'), 'missing_checkout');
  assert.equal(computeStatus(rec({ checkIn: at('09:00') }), rules, '2026-10-26'), 'present'); // still today
  assert.equal(computeStatus(rec({ checkIn: at('09:40'), late: true }), rules, '2026-10-26'), 'late');
});

test('attendance rate matches a hand-computed example', () => {
  // numerator 6 + 2 + 1 + 0.5*2 = 10 ; denominator 6+2+1+2+1 = 12 (on_leave excluded) => 83.33
  assert.equal(m.attendanceRate({ present: 6, late: 2, missing_checkout: 1, half_day: 2, absent: 1, on_leave: 4 }), 83.33);
});

test('attendance rate excludes on_leave from the denominator', () => {
  const rate = m.attendanceRate({ present: 6, late: 2, missing_checkout: 0, half_day: 2, absent: 2, on_leave: 99 });
  assert.equal(rate, 75); // (6+2+0+1) / 12
  assert.equal(m.attendanceRate({ on_leave: 5 }), null);
});

test('late %, absenteeism, attrition, leave utilization', () => {
  assert.equal(m.latePercent({ present: 18, late: 2 }), 10);
  assert.equal(m.absenteeism(3, 60), 5);
  assert.equal(m.attrition(2, 40, 36), 5.26); // 2 / 38
  assert.equal(m.leaveUtilization(7, 14), 50);
  assert.equal(m.attrition(1, 0, 0), null);
});

test('csv parser handles quotes, commas, newlines, BOM and CRLF', () => {
  const rows = parseCsv('\ufeffa,b,c\r\n1,"x, y","say ""hi"""\r\n"multi\nline",,3\r\n');
  assert.deepEqual(rows, [['a', 'b', 'c'], ['1', 'x, y', 'say "hi"'], ['multi\nline', '', '3']]);
});

test('csv writer neutralises formula injection and escapes quotes', () => {
  const out = toCsv([['=cmd()', '+1', '@x', 'a,b', 'q"q', 'ok']]);
  assert.equal(out, "'=cmd(),'+1,'@x,\"a,b\",\"q\"\"q\",ok\r\n");
});
