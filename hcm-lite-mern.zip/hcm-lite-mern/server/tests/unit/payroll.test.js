'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { computePayslip, annualTax, salaryStructure } = require('../../src/utils/payroll');

// October 2026: 1st is a Thursday. Weekend Sat/Sun => 22 working days.
const base = {
  basic: 100000,
  rules: { hraPercent: 40, medicalPercent: 10 },
  monthStart: '2026-10-01',
  monthEnd: '2026-10-31',
  joinDate: '2020-01-01',
  exitDate: null,
  weekend: [0, 6],
  holidays: [],
  attendance: {},
  leaves: {},
  today: '2026-11-15', // month fully elapsed
};

function fullAttendance(overrides = {}) {
  const att = {};
  for (let d = 1; d <= 31; d += 1) {
    const date = `2026-10-${String(d).padStart(2, '0')}`;
    const wd = new Date(`${date}T00:00:00Z`).getUTCDay();
    if (wd !== 0 && wd !== 6) att[date] = 'present';
  }
  return { ...att, ...overrides };
}

test('salary structure: gross = 1.5 x basic (HRA 40%, medical 10%)', () => {
  const s = salaryStructure(100000, { hraPercent: 40, medicalPercent: 10 });
  assert.deepEqual(s, { basic: 100000, hra: 40000, medical: 10000, gross: 150000 });
});

test('tax slabs follow the brief (annual gross)', () => {
  assert.equal(annualTax(600000), 0);
  assert.equal(annualTax(1200000), 30000);
  assert.equal(annualTax(1800000), 120000); // 30k + 15% of 600k
  assert.equal(annualTax(2400000), 210000);
  assert.equal(annualTax(3600000), 510000);
  assert.equal(annualTax(4600000), 860000); // 510k + 35% of 1M
});

test('full attendance => no deduction, tax = slab(gross x 12) / 12', () => {
  const p = computePayslip({ ...base, attendance: fullAttendance() });
  assert.equal(p.workingDays, 22);
  assert.equal(p.gross, 150000);
  assert.equal(p.deductDays, 0);
  assert.equal(p.earnedGross, 150000);
  assert.equal(p.tax, 10000); // 120000 / 12
  assert.equal(p.net, 140000);
});

test('absent day and unpaid leave deduct 1 day each; half day deducts 0.5', () => {
  const att = fullAttendance({ '2026-10-05': undefined, '2026-10-06': undefined, '2026-10-07': 'half_day' });
  delete att['2026-10-05'];
  delete att['2026-10-06'];
  const p = computePayslip({ ...base, attendance: att, leaves: { '2026-10-06': { paid: false } } });
  assert.equal(p.absentDays, 1); // 05th has nothing
  assert.equal(p.unpaidLeaveDays, 1); // 06th unpaid leave
  assert.equal(p.halfDays, 1);
  assert.equal(p.deductDays, 2.5);
  const perDay = 150000 / 22;
  assert.equal(p.deduction, Math.round(perDay * 2.5 * 100) / 100);
  assert.equal(p.payableGross, Math.round((150000 - perDay * 2.5) * 100) / 100);
});

test('paid leave does not reduce salary', () => {
  const att = fullAttendance();
  delete att['2026-10-12'];
  const p = computePayslip({ ...base, attendance: att, leaves: { '2026-10-12': { paid: true } } });
  assert.equal(p.paidLeaveDays, 1);
  assert.equal(p.absentDays, 0);
  assert.equal(p.deduction, 0);
  assert.equal(p.net, 140000);
});

test('public holidays are not working days and are never deducted', () => {
  const p = computePayslip({ ...base, holidays: ['2026-10-14'], attendance: fullAttendance({ '2026-10-14': undefined }) });
  assert.equal(p.workingDays, 21);
  assert.equal(p.absentDays, 0);
  assert.equal(p.deduction, 0);
  assert.equal(p.perDay, Math.round((150000 / 21) * 100) / 100);
});

test('attendance record wins over leave record on the same day', () => {
  const p = computePayslip({
    ...base,
    attendance: fullAttendance(),
    leaves: { '2026-10-08': { paid: false } },
  });
  assert.equal(p.unpaidLeaveDays, 0);
  assert.equal(p.deduction, 0);
});

test('joiner is prorated by eligible working days', () => {
  // joins Monday 19 Oct: working days 19-23, 26-30 = 10 of 22
  const att = {};
  for (const d of ['19', '20', '21', '22', '23', '26', '27', '28', '29', '30']) att[`2026-10-${d}`] = 'present';
  const p = computePayslip({ ...base, joinDate: '2026-10-19', attendance: att });
  assert.equal(p.eligibleDays, 10);
  assert.equal(p.absentDays, 0);
  assert.equal(p.earnedGross, Math.round(((150000 / 22) * 10) * 100) / 100);
});

test('leaver is prorated and days after exit are ignored', () => {
  const att = {};
  for (const d of ['01', '02', '05', '06', '07']) att[`2026-10-${d}`] = 'present';
  const p = computePayslip({ ...base, exitDate: '2026-10-07', attendance: att });
  assert.equal(p.eligibleDays, 5);
  assert.equal(p.absentDays, 0);
});

test('current month: today and future days are assumed worked, not absent', () => {
  const att = {};
  for (const d of ['01', '02', '05']) att[`2026-10-${d}`] = 'present';
  const p = computePayslip({ ...base, today: '2026-10-06', attendance: att });
  // evaluated: 1,2,5 (3 and 4 are Sat... 3rd Sat, 4th Sun) => all present
  assert.equal(p.absentDays, 0);
  assert.equal(p.deduction, 0);
});

test('missing_checkout counts as present (not deducted)', () => {
  const p = computePayslip({ ...base, attendance: fullAttendance({ '2026-10-09': 'missing_checkout' }) });
  assert.equal(p.deduction, 0);
});

test('tax never exceeds payable gross and net is never negative', () => {
  const p = computePayslip({ ...base, attendance: {} }); // absent every day
  assert.equal(p.absentDays, 22);
  assert.equal(p.payableGross, 0);
  assert.equal(p.tax, 0);
  assert.equal(p.net, 0);
});

test('income under the tax-free threshold pays no tax', () => {
  const p = computePayslip({ ...base, basic: 30000, attendance: fullAttendance() }); // gross 45k => 540k/yr
  assert.equal(p.tax, 0);
  assert.equal(p.net, 45000);
});
