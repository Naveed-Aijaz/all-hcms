'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { can, PERMISSIONS } = require('../../src/config/permissions');
const { employeeFilter, isEmployeeInScope, approvalFilter } = require('../../src/utils/scope');

const admin = { role: 'admin', employeeId: null };
const hr = { role: 'hr', employeeId: 'e-hr' };
const manager = { role: 'manager', employeeId: 'e-mgr' };
const employee = { role: 'employee', employeeId: 'e-1' };

test('employee cannot approve, manage payroll, import, or see audit log', () => {
  for (const p of ['leave:decide', 'correction:decide', 'payroll:read', 'payroll:run', 'payroll:finalize', 'employee:write', 'employee:import', 'audit:read', 'salary:read', 'settings:write', 'user:manage', 'announcement:post', 'ai:summary', 'payslip:any']) {
    assert.equal(can('employee', p), false, `employee must not have ${p}`);
  }
});

test('manager cannot touch payroll or salaries and cannot manage employees', () => {
  for (const p of ['payroll:read', 'payroll:run', 'payroll:finalize', 'salary:read', 'salary:write', 'employee:write', 'payslip:any', 'audit:read', 'settings:write']) {
    assert.equal(can('manager', p), false, `manager must not have ${p}`);
  }
  assert.equal(can('manager', 'leave:decide'), true);
});

test('only admin finalizes payroll; only HR runs it; HR cannot finalize', () => {
  assert.equal(can('admin', 'payroll:finalize'), true);
  assert.equal(can('hr', 'payroll:finalize'), false);
  assert.equal(can('hr', 'payroll:run'), true);
  assert.equal(can('admin', 'payroll:run'), false);
});

test('HR cannot change company settings or read the audit log; admin cannot check in', () => {
  assert.equal(can('hr', 'settings:write'), false);
  assert.equal(can('hr', 'audit:read'), false);
  assert.equal(can('admin', 'attendance:self'), false);
  assert.equal(can('admin', 'leave:self'), false);
});

test('unknown permission is denied', () => {
  assert.equal(can('admin', 'nope:nope'), false);
  assert.ok(Object.keys(PERMISSIONS).length > 20);
});

test('data scope: employee sees only self', () => {
  assert.deepEqual(employeeFilter(employee), { _id: 'e-1' });
  assert.equal(isEmployeeInScope(employee, { _id: 'e-1' }), true);
  assert.equal(isEmployeeInScope(employee, { _id: 'e-2', managerId: 'e-mgr' }), false);
});

test('data scope: manager sees self + direct reports only', () => {
  assert.deepEqual(employeeFilter(manager), { $or: [{ _id: 'e-mgr' }, { managerId: 'e-mgr' }] });
  assert.equal(isEmployeeInScope(manager, { _id: 'e-2', managerId: 'e-mgr' }), true);
  assert.equal(isEmployeeInScope(manager, { _id: 'e-3', managerId: 'someone-else' }), false);
  assert.equal(isEmployeeInScope(manager, { _id: 'e-4', managerId: null }), false);
  assert.equal(isEmployeeInScope(manager, { _id: 'e-mgr' }), true);
});

test('data scope: admin and HR see everyone; a user without an employee record sees nothing', () => {
  assert.deepEqual(employeeFilter(admin), {});
  assert.deepEqual(employeeFilter(hr), {});
  assert.equal(isEmployeeInScope(admin, { _id: 'x' }), true);
  assert.deepEqual(employeeFilter({ role: 'employee', employeeId: null }), { _id: null });
  assert.equal(isEmployeeInScope({ role: 'manager', employeeId: null }, { _id: 'x', managerId: null }), false);
});

test('approval inbox: manager never sees their own requests', () => {
  assert.deepEqual(approvalFilter(manager), { managerId: 'e-mgr' });
  assert.deepEqual(approvalFilter(employee), { _id: null });
  assert.deepEqual(approvalFilter(hr), {});
});
