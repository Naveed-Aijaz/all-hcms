'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const jwt = require('jsonwebtoken');
const h = require('./helpers');
const { User } = require('../../src/models');
const { newOpaqueToken } = require('../../src/utils/tokens');

let w;
test.before(async () => { await h.start(); w = await h.buildWorld(); });
test.after(h.stop);

test('first-run setup works once, then is closed (409)', async () => {
  assert.equal((await h.call('get', '/api/setup/status')).body.data.needsSetup, false);
  const again = await h.call('post', '/api/setup').send({ companyName: 'X', adminName: 'Y', adminEmail: 'y@x.test', adminPassword: 'Passw0rd!x' });
  assert.equal(again.status, 409);
});

test('login: wrong password and unknown email give the same 401; no password data leaks', async () => {
  const a = await h.call('post', '/api/auth/login').send({ email: 'admin@acme.test', password: 'wrong-pass1' });
  const b = await h.call('post', '/api/auth/login').send({ email: 'nobody@acme.test', password: 'wrong-pass1' });
  assert.equal(a.status, 401);
  assert.equal(b.status, 401);
  assert.equal(a.body.error.message, b.body.error.message);
  const ok = await h.call('post', '/api/auth/login').send({ email: 'admin@acme.test', password: 'Passw0rd!x' });
  assert.equal(ok.status, 200);
  assert.ok(ok.body.data.token);
  const raw = JSON.stringify(ok.body);
  assert.ok(!/passwordHash|resetToken/i.test(raw));
});

test('passwords are stored as bcrypt hashes', async () => {
  const u = await User.findOne({ email: 'admin@acme.test' }).select('+passwordHash').lean();
  assert.match(u.passwordHash, /^\$2[aby]\$\d{2}\$/);
  assert.notEqual(u.passwordHash, 'Passw0rd!x');
});

test('requests without / with invalid / expired tokens are rejected (401)', async () => {
  assert.equal((await h.call('get', '/api/auth/me')).status, 401);
  assert.equal((await h.call('get', '/api/auth/me', 'garbage')).status, 401);
  const u = await User.findOne({ email: 'admin@acme.test' });
  const expired = jwt.sign({ sub: String(u._id), tv: u.tokenVersion }, process.env.JWT_SECRET, { expiresIn: -10 });
  const r = await h.call('get', '/api/auth/me', expired);
  assert.equal(r.status, 401);
  const wrongKey = jwt.sign({ sub: String(u._id), tv: u.tokenVersion }, 'another-secret');
  assert.equal((await h.call('get', '/api/auth/me', wrongKey)).status, 401);
});

test('temporary password must be changed before using the API', async () => {
  const created = await h.call('post', '/api/employees', w.tokens.hr).send({ departmentId: w.ids.dept, joinDate: '2024-01-01', basicSalary: 50000, name: 'Tia Temp', email: 'tia@acme.test' });
  assert.equal(created.status, 201);
  const temp = created.body.data.temporaryPassword;
  const login = await h.call('post', '/api/auth/login').send({ email: 'tia@acme.test', password: temp });
  assert.equal(login.body.data.user.mustChangePassword, true);
  const blocked = await h.call('get', '/api/attendance/today', login.body.data.token);
  assert.equal(blocked.status, 403);
  assert.equal(blocked.body.error.code, 'PASSWORD_CHANGE_REQUIRED');
  const weak = await h.call('post', '/api/auth/change-password', login.body.data.token).send({ currentPassword: temp, newPassword: 'short' });
  assert.equal(weak.status, 422);
  const changed = await h.call('post', '/api/auth/change-password', login.body.data.token).send({ currentPassword: temp, newPassword: h.PASSWORD });
  assert.equal(changed.status, 200);
  assert.equal((await h.call('get', '/api/attendance/today', changed.body.data.token)).status, 200);
  // the old token no longer works (token version bumped)
  assert.equal((await h.call('get', '/api/auth/me', login.body.data.token)).status, 401);
});

test('forgot-password answers identically for known and unknown emails', async () => {
  const a = await h.call('post', '/api/auth/forgot-password').send({ email: 'e1@acme.test' });
  const b = await h.call('post', '/api/auth/forgot-password').send({ email: 'ghost@acme.test' });
  assert.equal(a.status, 200);
  assert.deepEqual(a.body, b.body);
  assert.match(a.body.data.message, /if an account exists/i);
  assert.ok(!/resetToken|[a-f0-9]{64}/i.test(JSON.stringify(a.body))); // no token in the response
});

test('password reset token: works once, then is rejected; expired tokens are rejected', async () => {
  const { token, hash } = newOpaqueToken();
  await User.updateOne({ email: 'e2@acme.test' }, { resetTokenHash: hash, resetTokenExpires: new Date(Date.now() + 60000) });
  const bad = await h.call('post', '/api/auth/reset-password').send({ token: 'a'.repeat(64), newPassword: 'Another1pass' });
  assert.equal(bad.status, 400);
  const good = await h.call('post', '/api/auth/reset-password').send({ token, newPassword: 'Another1pass' });
  assert.equal(good.status, 200);
  const replay = await h.call('post', '/api/auth/reset-password').send({ token, newPassword: 'Third1password' });
  assert.equal(replay.status, 400);
  assert.equal((await h.call('post', '/api/auth/login').send({ email: 'e2@acme.test', password: 'Another1pass' })).status, 200);
  // old session invalidated by the reset
  assert.equal((await h.call('get', '/api/auth/me', w.tokens.emp2)).status, 401);

  const t2 = newOpaqueToken();
  await User.updateOne({ email: 'e1@acme.test' }, { resetTokenHash: t2.hash, resetTokenExpires: new Date(Date.now() - 1000) });
  assert.equal((await h.call('post', '/api/auth/reset-password').send({ token: t2.token, newPassword: 'Another1pass' })).status, 400);
});

test('input validation and sanitisation', async () => {
  const r = await h.call('post', '/api/auth/login').send({ email: { $gt: '' }, password: 'x' });
  assert.equal(r.status, 422); // operator injection is stripped, then validation fails
  const bad = await h.call('post', '/api/departments', w.tokens.admin).send({ name: '' });
  assert.equal(bad.status, 422);
  const xss = await h.call('post', '/api/departments', w.tokens.admin).send({ name: '<script>alert(1)</script>Ops' });
  assert.equal(xss.status, 201);
  assert.equal(xss.body.data.name, 'alert(1)Ops');
});
