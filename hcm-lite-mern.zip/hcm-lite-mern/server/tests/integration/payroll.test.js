'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const h = require('./helpers');
const { AuditLog } = require('../../src/models');

let w;
let month;
let runId;
let slipIds = {};
const binary = (res, cb) => { const chunks = []; res.on('data', (c) => chunks.push(c)); res.on('end', () => cb(null, Buffer.concat(chunks))); };

test.before(async () => { await h.start(); w = await h.buildWorld(); month = h.today().slice(0, 7); });
test.after(h.stop);

test('only HR can create a draft; employees/managers/admin cannot', async () => {
  for (const t of [w.tokens.emp1, w.tokens.mgr, w.tokens.admin]) {
    assert.equal((await h.call('post', '/api/payroll/runs', t).send({ month })).status, 403);
  }
  assert.equal((await h.call('post', '/api/payroll/runs', w.tokens.hr).send({ month: '2999-01' })).status, 422); // future month
  assert.equal((await h.call('post', '/api/payroll/runs', w.tokens.hr).send({ month: '2026-13' })).status, 422);
  const r = await h.call('post', '/api/payroll/runs', w.tokens.hr).send({ month });
  assert.equal(r.status, 201);
  assert.equal(r.body.data.status, 'draft');
  assert.equal(r.body.data.totals.headcount, 4); // hr, manager, 2 employees (admin has no employee record)
  runId = r.body.data.id;
});

test('draft can be recomputed and contains the documented structure', async () => {
  const again = await h.call('post', '/api/payroll/runs', w.tokens.hr).send({ month });
  assert.equal(again.status, 201);
  assert.equal(again.body.data.id, runId); // same run, recalculated
  const detail = await h.call('get', `/api/payroll/runs/${runId}`, w.tokens.admin);
  assert.equal(detail.status, 200);
  assert.equal(detail.body.data.payslips.length, 4);
  for (const p of detail.body.data.payslips) {
    assert.equal(p.basic, 100000);
    assert.equal(p.hra, 40000);
    assert.equal(p.medical, 10000);
    assert.equal(p.gross, 150000);
    assert.equal(Math.round((p.payableGross - p.tax) * 100) / 100, p.net);
    assert.ok(p.net >= 0 && p.net <= p.payableGross);
    assert.ok(p.tax <= 10000.01); // slab(1.8M)/12
    slipIds[p.employee.id] = p.id;
  }
  assert.ok(!JSON.stringify(detail.body).match(/passwordHash|token/i));
});

test('employees cannot read draft payslips, nor anybody else’s', async () => {
  assert.equal((await h.call('get', `/api/payroll/payslips/${slipIds[w.ids.emp1]}`, w.tokens.emp1)).status, 403); // draft
  assert.equal((await h.call('get', '/api/payroll/payslips', w.tokens.emp1)).body.data.length, 0);
  assert.equal((await h.call('get', `/api/payroll/payslips/${slipIds[w.ids.emp2]}`, w.tokens.emp1)).status, 403);
  assert.equal((await h.call('get', `/api/payroll/payslips/${slipIds[w.ids.emp1]}`, w.tokens.hr)).status, 200); // HR may preview
});

test('only Admin finalizes; finalized months are locked', async () => {
  for (const t of [w.tokens.hr, w.tokens.mgr, w.tokens.emp1]) {
    assert.equal((await h.call('post', `/api/payroll/runs/${runId}/finalize`, t)).status, 403);
  }
  const fin = await h.call('post', `/api/payroll/runs/${runId}/finalize`, w.tokens.admin);
  assert.equal(fin.status, 200);
  assert.equal(fin.body.data.status, 'finalized');
  assert.equal((await h.call('post', `/api/payroll/runs/${runId}/finalize`, w.tokens.admin)).status, 409);
  const rerun = await h.call('post', '/api/payroll/runs', w.tokens.hr).send({ month });
  assert.equal(rerun.status, 409);
  assert.equal(rerun.body.error.code, 'PAYROLL_LOCKED');
});

test('after finalizing: employees read only their own payslip, salary edits do not alter it', async () => {
  const mine = await h.call('get', '/api/payroll/payslips', w.tokens.emp1);
  assert.equal(mine.body.data.length, 1);
  assert.equal(mine.body.data[0].employee.id, w.ids.emp1);
  assert.equal((await h.call('get', `/api/payroll/payslips/${slipIds[w.ids.emp1]}`, w.tokens.emp1)).status, 200);
  assert.equal((await h.call('get', `/api/payroll/payslips/${slipIds[w.ids.emp2]}`, w.tokens.emp1)).status, 403);
  assert.equal((await h.call('get', `/api/payroll/payslips?employeeId=${w.ids.emp2}`, w.tokens.emp1)).status, 403);
  assert.equal((await h.call('put', `/api/employees/${w.ids.emp1}/salary`, w.tokens.hr).send({ basicSalary: 250000 })).status, 200);
  const slip = await h.call('get', `/api/payroll/payslips/${slipIds[w.ids.emp1]}`, w.tokens.emp1);
  assert.equal(slip.body.data.basic, 100000);
  // notifications were delivered
  const notes = await h.call('get', '/api/notifications', w.tokens.emp1);
  assert.ok(notes.body.data.some((n) => n.type === 'payslip'));
});

test('payslip PDF downloads for the owner and for HR, and is refused for others', async () => {
  const pdf = await h.call('get', `/api/payroll/payslips/${slipIds[w.ids.emp1]}/pdf`, w.tokens.emp1).buffer(true).parse(binary);
  assert.equal(pdf.status, 200);
  assert.match(pdf.headers['content-type'], /application\/pdf/);
  assert.equal(pdf.body.slice(0, 4).toString(), '%PDF');
  assert.equal((await h.call('get', `/api/payroll/payslips/${slipIds[w.ids.emp2]}/pdf`, w.tokens.emp1)).status, 403);
  assert.equal((await h.call('get', `/api/payroll/payslips/${slipIds[w.ids.emp1]}/pdf`, w.tokens.hr).buffer(true).parse(binary)).status, 200);
});

test('audit log records payroll + salary changes and cannot be modified', async () => {
  const r = await h.call('get', '/api/audit?limit=100', w.tokens.admin);
  const actions = r.body.data.map((a) => a.action);
  assert.ok(actions.includes('payroll.draft'));
  assert.ok(actions.includes('payroll.finalize'));
  assert.ok(actions.includes('employee.salary_update'));
  await assert.rejects(() => AuditLog.updateOne({}, { $set: { action: 'x' } }));
  await assert.rejects(() => AuditLog.deleteMany({}));
  assert.equal((await h.call('delete', '/api/audit', w.tokens.admin)).status, 404); // no delete endpoint exists
});

test('CSV import: dry run reports row + field + reason, real import is all-or-nothing', async () => {
  const header = 'name,email,department,join_date,basic_salary,role\n';
  const csv = Buffer.from(`${header}Good One,good@acme.test,Engineering,2024-01-02,50000,employee\nBad Mail,not-an-email,Nowhere,2024-13-45,-5,employee\n`);
  const dry = await h.call('post', '/api/employees/import?dryRun=true', w.tokens.hr).attach('file', csv, { filename: 'e.csv', contentType: 'text/csv' });
  assert.equal(dry.status, 200);
  assert.equal(dry.body.data.dryRun, true);
  const fields = dry.body.data.errors.map((e) => `${e.row}:${e.field}`);
  for (const f of ['3:email', '3:department', '3:join_date', '3:basic_salary']) assert.ok(fields.includes(f), f);
  assert.ok(dry.body.data.errors.every((e) => e.reason));
  const real = await h.call('post', '/api/employees/import', w.tokens.hr).attach('file', csv, { filename: 'e.csv', contentType: 'text/csv' });
  assert.equal(real.status, 422);
  const list = await h.call('get', '/api/employees?search=good', w.tokens.hr);
  assert.equal(list.body.data.length, 0); // nothing imported
  const okCsv = Buffer.from(`${header}Good One,good@acme.test,Engineering,2024-01-02,50000,employee\n`);
  const done = await h.call('post', '/api/employees/import', w.tokens.hr).attach('file', okCsv, { filename: 'e.csv', contentType: 'text/csv' });
  assert.equal(done.status, 201);
  assert.equal(done.body.data.imported, 1);
});
