'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const h = require('./helpers');
const { Attendance } = require('../../src/models');

let w;
test.before(async () => { await h.start(); w = await h.buildWorld(); });
test.after(h.stop);

test('check-out before check-in is refused (409)', async () => {
  const r = await h.call('post', '/api/attendance/check-out', w.tokens.emp1);
  assert.equal(r.status, 409);
  assert.equal(r.body.error.code, 'NOT_CHECKED_IN');
});

test('first check-in succeeds, the second is a 409; the server stamps the time', async () => {
  const before = Date.now();
  const first = await h.call('post', '/api/attendance/check-in', w.tokens.emp1).send({ checkIn: '1999-01-01T00:00:00Z' }); // client time ignored
  assert.equal(first.status, 201);
  const stamped = new Date(first.body.data.checkIn).getTime();
  assert.ok(stamped >= before - 1000 && stamped <= Date.now() + 1000);
  assert.equal(first.body.data.date, h.today());
  const second = await h.call('post', '/api/attendance/check-in', w.tokens.emp1);
  assert.equal(second.status, 409);
  assert.equal(second.body.error.code, 'ALREADY_CHECKED_IN');
  assert.equal(await Attendance.countDocuments({ employeeId: w.ids.emp1, date: h.today() }), 1);
});

test('simultaneous check-ins create exactly one record', async () => {
  const results = await Promise.all([1, 2, 3, 4].map(() => h.call('post', '/api/attendance/check-in', w.tokens.emp2)));
  const codes = results.map((r) => r.status).sort();
  assert.deepEqual(codes, [201, 409, 409, 409]);
  assert.equal(await Attendance.countDocuments({ employeeId: w.ids.emp2, date: h.today() }), 1);
});

test('check-out records the worked duration; a second check-out is a 409', async () => {
  // move the check-in 6h30m into the past so the duration is deterministic-ish
  const past = new Date(Date.now() - (6 * 60 + 30) * 60000);
  await Attendance.updateOne({ employeeId: w.ids.emp1, date: h.today() }, { $set: { checkIn: past } });
  const out = await h.call('post', '/api/attendance/check-out', w.tokens.emp1);
  assert.equal(out.status, 200);
  assert.ok(out.body.data.workedMinutes >= 390 && out.body.data.workedMinutes <= 392, `got ${out.body.data.workedMinutes}`);
  assert.ok(['present', 'late'].includes(out.body.data.status)); // >= 5h => not a half day
  const again = await h.call('post', '/api/attendance/check-out', w.tokens.emp1);
  assert.equal(again.status, 409);
});

test('worked < 5 hours becomes half_day', async () => {
  const past = new Date(Date.now() - 2 * 3600000);
  await Attendance.updateOne({ employeeId: w.ids.emp2, date: h.today() }, { $set: { checkIn: past } });
  const out = await h.call('post', '/api/attendance/check-out', w.tokens.emp2);
  assert.equal(out.body.data.status, 'half_day');
});

test('late rule uses office start + grace and is snapshotted on the record', async () => {
  // Make "late" impossible (start 23:59 + 180 min grace crosses midnight), then check in the manager.
  const s = await h.call('put', '/api/settings', w.tokens.admin).send({ officeStart: '23:59', graceMinutes: 180 });
  assert.equal(s.status, 200);
  const ok = await h.call('post', '/api/attendance/check-in', w.tokens.mgr);
  assert.equal(ok.body.data.late, false);
  // Now make everyone late (start 00:00, grace 0): existing record keeps its rules, new records are late.
  await h.call('put', '/api/settings', w.tokens.admin).send({ officeStart: '00:00', graceMinutes: 0 });
  const hrIn = await h.call('post', '/api/attendance/check-in', w.tokens.hr);
  assert.equal(hrIn.body.data.late, true);
  assert.equal(hrIn.body.data.status, 'late');
  const mgrRec = await Attendance.findOne({ employeeId: w.ids.mgr, date: h.today() }).lean();
  assert.equal(mgrRec.late, false);
  assert.equal(mgrRec.rules.startTime, '23:59');
});

test('attendance board: HR sees everyone, status reflects records', async () => {
  const r = await h.call('get', '/api/attendance/board', w.tokens.hr);
  assert.equal(r.status, 200);
  const byId = Object.fromEntries(r.body.data.data.map((x) => [x.employeeId, x.status]));
  assert.ok(byId[w.ids.emp1]);
  assert.equal(byId[w.ids.hr], 'late');
});

test('monthly calendar returns the caller’s own days only', async () => {
  const r = await h.call('get', '/api/attendance/me', w.tokens.emp1);
  assert.equal(r.status, 200);
  assert.ok(r.body.data.days.length >= 28);
  assert.equal(r.body.data.days.find((d) => d.date === h.today()).checkIn !== null, true);
});

test('corrections: request, no self-approval, manager only for team, HR approves and record is created', async () => {
  const yesterday = require('../../src/utils/dates').addDays(h.today(), -1);
  const req = await h.call('post', '/api/attendance/corrections', w.tokens.emp2).send({ date: yesterday, checkIn: '09:00', checkOut: '17:30', reason: 'Forgot to check in' });
  assert.equal(req.status, 201);
  const dup = await h.call('post', '/api/attendance/corrections', w.tokens.emp2).send({ date: yesterday, checkIn: '09:00', reason: 'again' });
  assert.equal(dup.status, 409);
  const bad = await h.call('post', '/api/attendance/corrections', w.tokens.emp2).send({ date: yesterday, checkIn: '17:00', checkOut: '09:00', reason: 'x' });
  assert.equal(bad.status, 422);
  // employee cannot approve; manager cannot approve someone outside the team (emp2 has no manager)
  assert.equal((await h.call('post', `/api/attendance/corrections/${req.body.data.id}/decision`, w.tokens.emp1).send({ decision: 'approve' })).status, 403);
  assert.equal((await h.call('post', `/api/attendance/corrections/${req.body.data.id}/decision`, w.tokens.mgr).send({ decision: 'approve' })).status, 403);
  const approved = await h.call('post', `/api/attendance/corrections/${req.body.data.id}/decision`, w.tokens.hr).send({ decision: 'approve', comment: 'ok' });
  assert.equal(approved.status, 200);
  const rec = await Attendance.findOne({ employeeId: w.ids.emp2, date: yesterday }).lean();
  assert.ok(rec && rec.source === 'correction' && rec.workedMinutes === 510);
  const twice = await h.call('post', `/api/attendance/corrections/${req.body.data.id}/decision`, w.tokens.hr).send({ decision: 'reject', comment: 'no' });
  assert.equal(twice.status, 409);
});
