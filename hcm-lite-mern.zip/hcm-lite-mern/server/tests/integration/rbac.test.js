'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const h = require('./helpers');

let w;
test.before(async () => { await h.start(); w = await h.buildWorld(); });
test.after(h.stop);

const status = async (method, url, token, body) => (await h.call(method, url, token).send(body)).status;

test('unauthenticated access is refused everywhere', async () => {
  for (const u of ['/api/employees', '/api/payroll/runs', '/api/audit', '/api/settings', '/api/leaves']) {
    assert.equal(await status('get', u), 401, u);
  }
});

test('employee cannot use HR/Admin/payroll/audit endpoints', async () => {
  const t = w.tokens.emp1;
  for (const u of ['/api/payroll/runs', '/api/audit', '/api/users', '/api/attendance/board', '/api/dashboard/hr', '/api/dashboard/admin', '/api/employees/export']) {
    assert.equal(await status('get', u, t), 403, u);
  }
  assert.equal(await status('put', '/api/settings', t, { graceMinutes: 90 }), 403);
  assert.equal(await status('post', '/api/employees', t, {}), 403);
  assert.equal(await status('post', '/api/payroll/runs', t, { month: '2026-10' }), 403);
  assert.equal(await status('post', '/api/ai/summary', t, { dashboard: 'hr' }), 403);
});

test('employee sees only their own record in lists and 403s on others', async () => {
  const list = await h.call('get', '/api/employees', w.tokens.emp1);
  assert.equal(list.status, 200);
  assert.equal(list.body.data.length, 1);
  assert.equal(list.body.data[0].id, w.ids.emp1);
  assert.equal(list.body.data[0].salary, undefined); // no pay data for employees
  assert.equal(await status('get', `/api/employees/${w.ids.emp2}`, w.tokens.emp1), 403);
  assert.equal(await status('get', `/api/attendance/employee/${w.ids.emp2}`, w.tokens.emp1), 403);
  assert.equal(await status('get', `/api/leaves/balance?employeeId=${w.ids.emp2}`, w.tokens.emp1), 403);
  const self = await h.call('get', `/api/employees/${w.ids.emp1}`, w.tokens.emp1);
  assert.equal(self.status, 200);
  assert.equal(self.body.data.profile.salary, undefined);
});

test('manager team boundary: sees self + direct reports only', async () => {
  const list = await h.call('get', '/api/employees', w.tokens.mgr);
  const ids = list.body.data.map((e) => e.id).sort();
  assert.deepEqual(ids, [w.ids.mgr, w.ids.emp1].sort());
  assert.equal(await status('get', `/api/employees/${w.ids.emp1}`, w.tokens.mgr), 200);
  assert.equal(await status('get', `/api/employees/${w.ids.emp2}`, w.tokens.mgr), 403); // not on the team
  assert.equal(await status('get', `/api/employees/${w.ids.hr}`, w.tokens.mgr), 403);
  const board = await h.call('get', '/api/attendance/board', w.tokens.mgr);
  assert.deepEqual(board.body.data.data.map((r) => r.employeeId), [w.ids.emp1]);
});

test('manager and employee are locked out of payroll and salary data', async () => {
  for (const t of [w.tokens.mgr, w.tokens.emp1]) {
    assert.equal(await status('get', '/api/payroll/runs', t), 403);
    assert.equal(await status('put', `/api/employees/${w.ids.emp1}/salary`, t, { basicSalary: 1 }), 403);
    assert.equal(await status('get', `/api/payroll/payslips?employeeId=${w.ids.emp2}`, t), 403);
  }
  const mgrView = await h.call('get', `/api/employees/${w.ids.emp1}`, w.tokens.mgr);
  assert.equal(mgrView.body.data.profile.salary, undefined);
});

test('HR cannot change settings, finalize payroll, or read the audit log; HR can see salaries', async () => {
  assert.equal(await status('put', '/api/settings', w.tokens.hr, { graceMinutes: 30 }), 403);
  assert.equal(await status('get', '/api/audit', w.tokens.hr), 403);
  assert.equal(await status('post', '/api/departments', w.tokens.hr, { name: 'X' }), 403);
  assert.equal(await status('post', '/api/users/hr', w.tokens.hr, {}), 403);
  const v = await h.call('get', `/api/employees/${w.ids.emp1}`, w.tokens.hr);
  assert.equal(v.body.data.profile.salary.gross, 150000);
});

test('Admin can read audit log; audit entries never contain passwords', async () => {
  const r = await h.call('get', '/api/audit?limit=100', w.tokens.admin);
  assert.equal(r.status, 200);
  assert.ok(r.body.data.length > 0);
  assert.ok(!/passwordHash|temporaryPassword|Passw0rd/i.test(JSON.stringify(r.body)));
});

test('admin has no employee record: cannot check in or apply for leave', async () => {
  assert.equal(await status('post', '/api/attendance/check-in', w.tokens.admin), 403);
  assert.equal(await status('post', '/api/leaves', w.tokens.admin, { leaveTypeId: '0'.repeat(24), startDate: '2026-12-01', endDate: '2026-12-01' }), 403);
});

test('invalid ids are rejected cleanly', async () => {
  assert.equal(await status('get', '/api/employees/not-an-id', w.tokens.hr), 422);
});

test('mass assignment: role / salary fields cannot be injected through self-update', async () => {
  const r = await h.call('patch', '/api/employees/me', w.tokens.emp1).send({ phone: '0300 1234567', role: 'hr', salary: { basic: 9999999 } });
  assert.equal(r.status, 200);
  assert.equal(r.body.data.role, 'employee');
  const check = await h.call('get', `/api/employees/${w.ids.emp1}`, w.tokens.hr);
  assert.equal(check.body.data.profile.salary.basic, 100000);
});

test('profile upload rejects non-images and wrong content, accepts a real PNG', async () => {
  const fake = await h.call('post', '/api/employees/me/photo', w.tokens.emp1).attach('photo', Buffer.from('<?php echo 1; ?>'), { filename: 'evil.png', contentType: 'image/png' });
  assert.equal(fake.status, 415);
  const text = await h.call('post', '/api/employees/me/photo', w.tokens.emp1).attach('photo', Buffer.from('hello'), { filename: 'a.txt', contentType: 'text/plain' });
  assert.equal(text.status, 415);
  const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(64)]);
  const ok = await h.call('post', '/api/employees/me/photo', w.tokens.emp1).attach('photo', png, { filename: '../../x.png', contentType: 'image/png' });
  assert.equal(ok.status, 200);
  assert.match(ok.body.data.photo, /^[a-f0-9]{32}\.png$/); // server-generated name, client filename ignored
  const big = await h.call('post', '/api/employees/me/photo', w.tokens.emp1).attach('photo', Buffer.concat([png, Buffer.alloc(3 * 1024 * 1024)]), { filename: 'big.png', contentType: 'image/png' });
  assert.equal(big.status, 413);
});
