'use strict';
// Environment must be configured BEFORE any src module is required.
process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'integration-test-secret-integration-test-secret';
process.env.BCRYPT_ROUNDS = '4';
process.env.RATE_LIMIT_DISABLED = 'true';
process.env.MAIL_MODE = 'off';
process.env.EXPOSE_TEMP_PASSWORD = 'true';
process.env.UPLOAD_DIR = require('path').join(require('os').tmpdir(), `hcm-uploads-${process.pid}`);

const mongoose = require('mongoose');
const request = require('supertest');
const { MongoMemoryServer } = require('mongodb-memory-server');
const { createApp } = require('../../src/app');
const { dateInTz, addDays, weekdayOf } = require('../../src/utils/dates');

let mongod;
let app;

async function start() {
  mongod = await MongoMemoryServer.create();
  await mongoose.connect(mongod.getUri());
  await mongoose.syncIndexes();
  app = createApp();
  return app;
}
async function stop() {
  await mongoose.disconnect();
  if (mongod) await mongod.stop();
}

const call = (method, url, token) => {
  const r = request(app)[method](url);
  return token ? r.set('Authorization', `Bearer ${token}`) : r;
};

const TZ = 'Asia/Karachi';
const today = () => dateInTz(new Date(), TZ);
/** First Monday strictly after `from`. */
function nextMonday(from = today()) {
  let d = addDays(from, 1);
  while (weekdayOf(d) !== 1) d = addDays(d, 1);
  return d;
}

const PASSWORD = 'NewPassw0rd!';

/** Log in with the temporary password and complete the forced password change. */
async function activate(email, temp) {
  const login = await call('post', '/api/auth/login').send({ email, password: temp });
  const changed = await call('post', '/api/auth/change-password', login.body.data.token).send({ currentPassword: temp, newPassword: PASSWORD });
  return changed.body.data.token;
}

/** Builds: admin, one department, an HR user, a manager, two employees (emp1 reports to the manager, emp2 does not). */
async function buildWorld() {
  const setup = await call('post', '/api/setup').send({ companyName: 'Acme', adminName: 'Ada Admin', adminEmail: 'admin@acme.test', adminPassword: 'Passw0rd!x', seedDefaults: true });
  const admin = setup.body.data.token;
  const dept = (await call('post', '/api/departments', admin).send({ name: 'Engineering' })).body.data;
  const base = { departmentId: dept.id, joinDate: '2020-01-01', basicSalary: 100000 };

  const hrRes = (await call('post', '/api/users/hr', admin).send({ ...base, name: 'Hana HR', email: 'hr@acme.test' })).body.data;
  const hr = await activate('hr@acme.test', hrRes.temporaryPassword);

  const mgrRes = (await call('post', '/api/employees', hr).send({ ...base, name: 'Mo Manager', email: 'mgr@acme.test', role: 'manager' })).body.data;
  const mgr = await activate('mgr@acme.test', mgrRes.temporaryPassword);

  const e1 = (await call('post', '/api/employees', hr).send({ ...base, name: 'Eve One', email: 'e1@acme.test', managerId: mgrRes.employee.id })).body.data;
  const emp1 = await activate('e1@acme.test', e1.temporaryPassword);
  const e2 = (await call('post', '/api/employees', hr).send({ ...base, name: 'Eli Two', email: 'e2@acme.test' })).body.data;
  const emp2 = await activate('e2@acme.test', e2.temporaryPassword);

  return {
    tokens: { admin, hr, mgr, emp1, emp2 },
    ids: { dept: dept.id, hr: hrRes.employee.id, mgr: mgrRes.employee.id, emp1: e1.employee.id, emp2: e2.employee.id },
    hrRes,
  };
}

module.exports = { start, stop, call, buildWorld, activate, today, nextMonday, PASSWORD, mongoose, TZ };
