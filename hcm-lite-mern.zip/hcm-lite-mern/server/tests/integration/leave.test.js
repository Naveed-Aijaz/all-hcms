'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const h = require('./helpers');
const { addDays } = require('../../src/utils/dates');

let w;
let types;
test.before(async () => {
  await h.start();
  w = await h.buildWorld();
  const list = (await h.call('get', '/api/leave-types', w.tokens.admin)).body.data;
  types = Object.fromEntries(list.map((t) => [t.code, t.id]));
});
test.after(h.stop);

const apply = (token, code, startDate, endDate, reason = 'test') => h.call('post', '/api/leaves', token).send({ leaveTypeId: types[code], startDate, endDate, reason });

test('default leave types: annual 14, sick 8, casual 10, unpaid unlimited', async () => {
  const b = (await h.call('get', '/api/leaves/balance', w.tokens.emp1)).body.data;
  const q = Object.fromEntries(b.map((x) => [x.code, x]));
  assert.equal(q.ANNUAL.quota, 14);
  assert.equal(q.SICK.quota, 8);
  assert.equal(q.CASUAL.quota, 10);
  assert.equal(q.UNPAID.unlimited, true);
});

test('Monday+Tuesday request counts 2 working days; weekends are skipped', async () => {
  const mon = h.nextMonday(addDays(h.today(), 7));
  const r = await apply(w.tokens.emp1, 'CASUAL', mon, addDays(mon, 1), 'wedding');
  assert.equal(r.status, 201);
  assert.equal(r.body.data.days, 2);
  assert.equal(r.body.data.status, 'pending');
  w.firstLeave = r.body.data.id;
  w.firstMon = mon;
  // Mon..next Mon spans a weekend => 6 working days
  const long = await h.call('post', '/api/leaves/preview', w.tokens.emp2).send({ leaveTypeId: types.CASUAL, startDate: mon, endDate: addDays(mon, 7) });
  assert.equal(long.body.data.days, 6);
});

test('validation: end before start, weekend-only, overlap, over-balance, spans years → 422', async () => {
  const mon = w.firstMon;
  assert.equal((await apply(w.tokens.emp1, 'SICK', addDays(mon, 20), addDays(mon, 19))).status, 422);
  const sat = addDays(mon, 5);
  const weekendOnly = await apply(w.tokens.emp1, 'SICK', sat, addDays(sat, 1));
  assert.equal(weekendOnly.status, 422);
  assert.equal(weekendOnly.body.error.code, 'NO_WORKING_DAYS');
  const overlap = await apply(w.tokens.emp1, 'ANNUAL', addDays(mon, 1), addDays(mon, 2));
  assert.equal(overlap.status, 422);
  assert.equal(overlap.body.error.code, 'OVERLAP');
  const tooMany = await apply(w.tokens.emp2, 'SICK', addDays(mon, 14), addDays(mon, 28)); // 11 working days > 8
  assert.equal(tooMany.status, 422);
  assert.equal(tooMany.body.error.code, 'INSUFFICIENT_BALANCE');
  assert.equal((await apply(w.tokens.emp2, 'UNPAID', addDays(mon, 14), addDays(mon, 28))).status, 201); // unpaid is unlimited
  const ny = await apply(w.tokens.emp2, 'ANNUAL', `${Number(h.today().slice(0, 4)) + 1}-12-30`, `${Number(h.today().slice(0, 4)) + 2}-01-02`);
  assert.equal(ny.status, 422);
});

test('public holidays are excluded from the day count', async () => {
  const mon = h.nextMonday(addDays(h.today(), 60));
  await h.call('post', '/api/holidays', w.tokens.admin).send({ date: addDays(mon, 1), name: 'Test Holiday' });
  const p = await h.call('post', '/api/leaves/preview', w.tokens.emp1).send({ leaveTypeId: types.ANNUAL, startDate: mon, endDate: addDays(mon, 2) });
  assert.equal(p.body.data.days, 2); // Mon, Wed
});

test('pending requests reserve balance; approval flow respects team boundaries', async () => {
  const bal = (await h.call('get', '/api/leaves/balance', w.tokens.emp1)).body.data.find((x) => x.code === 'CASUAL');
  assert.equal(bal.pending, 2);
  assert.equal(bal.remaining, 8);
  // approval inbox: manager sees the report's request, emp2 request is invisible to the manager
  const inbox = await h.call('get', '/api/leaves?status=pending', w.tokens.mgr);
  assert.ok(inbox.body.data.every((l) => l.employee.id === w.ids.emp1));
  assert.equal(inbox.body.data.length, 1);
  // an employee cannot decide
  assert.equal((await h.call('post', `/api/leaves/${w.firstLeave}/decision`, w.tokens.emp2).send({ decision: 'approve' })).status, 403);
  // reject needs a comment
  assert.equal((await h.call('post', `/api/leaves/${w.firstLeave}/decision`, w.tokens.mgr).send({ decision: 'reject' })).status, 422);
  const approved = await h.call('post', `/api/leaves/${w.firstLeave}/decision`, w.tokens.mgr).send({ decision: 'approve', comment: 'enjoy' });
  assert.equal(approved.status, 200);
  assert.equal(approved.body.data.status, 'approved');
  const again = await h.call('post', `/api/leaves/${w.firstLeave}/decision`, w.tokens.hr).send({ decision: 'reject', comment: 'late' });
  assert.equal(again.status, 409);
  const after = (await h.call('get', '/api/leaves/balance', w.tokens.emp1)).body.data.find((x) => x.code === 'CASUAL');
  assert.equal(after.used, 2);
  assert.equal(after.pending, 0);
  assert.equal(after.remaining, 8);
});

test('manager cannot decide outside the team, nobody decides their own request', async () => {
  const mon = h.nextMonday(addDays(h.today(), 90));
  const other = await apply(w.tokens.emp2, 'CASUAL', mon, mon);
  assert.equal((await h.call('post', `/api/leaves/${other.body.data.id}/decision`, w.tokens.mgr).send({ decision: 'approve' })).status, 403);
  const mine = await apply(w.tokens.mgr, 'CASUAL', mon, mon);
  assert.equal((await h.call('post', `/api/leaves/${mine.body.data.id}/decision`, w.tokens.mgr).send({ decision: 'approve' })).status, 403);
  assert.equal((await h.call('post', `/api/leaves/${mine.body.data.id}/decision`, w.tokens.hr).send({ decision: 'approve' })).status, 200); // HR approves a manager
  const hrOwn = await apply(w.tokens.hr, 'CASUAL', mon, mon);
  assert.equal((await h.call('post', `/api/leaves/${hrOwn.body.data.id}/decision`, w.tokens.hr).send({ decision: 'approve' })).status, 403);
  assert.equal((await h.call('post', `/api/leaves/${hrOwn.body.data.id}/decision`, w.tokens.admin).send({ decision: 'approve' })).status, 200); // Admin only for HR requests
  assert.equal((await h.call('post', `/api/leaves/${other.body.data.id}/decision`, w.tokens.admin).send({ decision: 'approve' })).status, 403);
});

test('employee can cancel own pending leave, not someone else’s; cancelled leave frees the balance', async () => {
  const mon = h.nextMonday(addDays(h.today(), 120));
  const r = await apply(w.tokens.emp1, 'ANNUAL', mon, addDays(mon, 3));
  assert.equal((await h.call('post', `/api/leaves/${r.body.data.id}/cancel`, w.tokens.emp2)).status, 403);
  assert.equal((await h.call('post', `/api/leaves/${r.body.data.id}/cancel`, w.tokens.emp1)).status, 200);
  const bal = (await h.call('get', '/api/leaves/balance', w.tokens.emp1)).body.data.find((x) => x.code === 'ANNUAL');
  assert.equal(bal.pending, 0);
  assert.equal((await h.call('post', `/api/leaves/${r.body.data.id}/cancel`, w.tokens.emp1)).status, 409);
});

test('employees only list their own requests', async () => {
  const r = await h.call('get', '/api/leaves', w.tokens.emp2);
  assert.ok(r.body.data.every((l) => l.employee.id === w.ids.emp2));
});
